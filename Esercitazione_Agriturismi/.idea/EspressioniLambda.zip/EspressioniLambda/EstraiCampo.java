package EspressioniLambda;

@FunctionalInterface
public interface EstraiCampo<T> {

    T estrai(Film film);
}
