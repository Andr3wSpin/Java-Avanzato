package EspressioniLambda;

import java.util.List;

public class Main {

    public static void main(String[] args) {

        Videoteca videoteca = new Videoteca();

        videoteca.aggiungi(new Film("Fast & Furious", Genere.AZIONE,  10));
        videoteca.aggiungi((new Film("Hulk", Genere.AZIONE, 6)));
        videoteca.aggiungi(new Film("La vita è bella", Genere.DRAMMATICO, 10));
        videoteca.aggiungi(new Film("Sharknado", Genere.THRILLER, 10));
        videoteca.aggiungi(new Film("Benvenuti al Sud", Genere.COMMEDIA, 8));

        System.out.println(videoteca);

        Videoteca v2 = videoteca.filtra(film -> film.getGenere().equals(Genere.AZIONE))
                .filtra(film -> film.getValutazione() > 6 );

        System.out.println(v2);
            
        v2.aggiorna(film -> film.setValutazione(8));

        System.out.println(v2);

        System.out.println(videoteca);

        List<?> titoli = videoteca.estraiCampo(film -> film.getTitolo());

        System.out.println(titoli);

        //REFERENCE A METODI
        //metodi statici
        Videoteca v3 = videoteca.filtra(Filtri::isBelFilm);

        System.out.println(v3);

        //metodi di istanza
        Filtri filtri = new Filtri();

        Videoteca v4 = v3.filtra(filtri::isFantascienza);

        List<?> valutazioni = videoteca.estraiCampo(Film::getValutazione);
    }
}
