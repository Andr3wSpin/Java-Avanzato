package EspressioniLambda;

@FunctionalInterface
public interface FiltroFilm {

    boolean verifica(Film film);
}
