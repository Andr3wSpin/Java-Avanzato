package EspressioniLambda;

import java.util.ArrayList;
import java.util.List;

public class Videoteca {

    private List<Film> videoteca;

    public Videoteca() {

        videoteca = new ArrayList<>();
    }

    public void aggiungi(Film film) { videoteca.add(film); }

    public Videoteca filtra(FiltroFilm filtro) {

        Videoteca v = new Videoteca();

        for(Film film : videoteca) {

            if(filtro.verifica(film)) v.aggiungi(film);
        }

        return v;
    }

    public void aggiorna(AggiornaFilm af) {

        for(Film film : videoteca) af.aggiorna(film);
    }

    public <T> List<T> estraiCampo(EstraiCampo<T> ec) {

        List<T> campi = new ArrayList();

        for(Film film : videoteca) {

            campi.add(ec.estrai(film));
        }

        return campi;
    }

    @Override
    public String toString() {

        StringBuilder sb = new StringBuilder();

        for(Film film : videoteca) sb.append(film + "\n");

        return sb.toString();
    }
}
