package EspressioniLambda;

public enum Genere {

    COMMEDIA, THRILLER, FANTASCIENZA, AZIONE, DRAMMATICO;
}
