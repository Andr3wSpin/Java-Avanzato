package EspressioniLambda;

public interface AggiornaFilm {

    void aggiorna(Film film);
}
